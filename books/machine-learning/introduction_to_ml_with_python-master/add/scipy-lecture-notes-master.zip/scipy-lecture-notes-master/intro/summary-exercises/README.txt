Examples for the summary excercises
====================================



