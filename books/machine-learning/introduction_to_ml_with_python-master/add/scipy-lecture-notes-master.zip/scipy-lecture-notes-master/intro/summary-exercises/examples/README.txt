Examples for the summary excercices
====================================

