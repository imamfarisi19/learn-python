Examples for the image processing chapter
=========================================

