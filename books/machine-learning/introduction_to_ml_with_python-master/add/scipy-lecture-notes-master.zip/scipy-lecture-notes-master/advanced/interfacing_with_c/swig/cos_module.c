#include <math.h>

double cos_func(double arg){
    return cos(arg);
}
