Examples for the scipy sparse matrix chapter
=============================================

