Examples for the scikit-learn chapter
======================================

