Examples for the Mayavi chapter
================================

